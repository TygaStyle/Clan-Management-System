<?
// Basic Variables...
$titlepage = "Welcome To EXG'S ROSTER";
/*

=======CREATE NEW DB TABLE=======

CREATE TABLE name
(
id int NOT NULL AUTO_INCREMENT,
PRIMARY KEY(id),

name1 varchar(1),
name2 varchar(10)
)

*/
?>