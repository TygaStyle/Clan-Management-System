<?php
$table['bgcolor'] = "000000";
?>