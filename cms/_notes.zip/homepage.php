<div class="center_header">
Welcome to EXG Clan
</div><div class="center_content">
  <div class="news_post"> Hello and welcome to EXG Clan. Here we list all of our members and divisions in EXG. If you find any problem please go to the forums and make a topic under site errors thanks. We also have as you can see 
below displayed Bungie.net News. It always updates with the latest Bungie.net news, however it only displays the short segment you see on bungie.net. But at 
least you can stay up to date with bungie. </div>
</div>