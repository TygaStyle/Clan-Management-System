<?
session_start();
##############################################################################################
$connection = mysql_connect("localhost", "bulldog1_ljay", "d1150102");
mysql_select_db("bulldog1_ljay", $connection);
##############################################################################################
include("functions/functions.php");
logfile($_SESSION['id'], "Logged Out ".date('h:i:s A'));
unset($_SESSION['id']);
unset($_SESSION['selectid']);
header("Location: index.php");
?>
