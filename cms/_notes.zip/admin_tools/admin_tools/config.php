<?php 
// SESSION LOGIN

// user 1
$username = "248fe54b54d8060701907f2c4b89e1af";
$password = "fb52c4a1d6e1e5067c0b723dfa501101";

// user 2
$username2 = "cbb11ed87dc8a95d81400c7f33c7c171";
$password2 = "ccfb77278908b07ef49af6cbb9e16c6a";

//  DATABASE

$titlepage = 'Clan.net Admin Tools';
$location = 'localhost';
$database = 'admin_clan';
$dbusername = 'admin';  
$dbpassword = 'maxine2';


# --------- Do not edit below this line! --------- #
$connection = mysql_connect("$location","$dbusername","$dbpassword");
session_start();

?>